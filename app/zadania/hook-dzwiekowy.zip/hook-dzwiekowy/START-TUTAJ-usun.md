# Start tutaj (przeczytaj i usuń ten plik)

W tym zadaniu ustawisz jedną, bardzo przydatną rzecz: Claude Code będzie wydawał dźwięk, gdy skończy odpowiadać, i inny, gdy czeka na Twoją decyzję. Dzięki temu możesz zająć się czymś innym i wracać dokładnie wtedy, gdy trzeba.

Ustawimy to globalnie, czyli tak, że zadziała w każdym Twoim projekcie, nie tylko w tym folderze.

## Co zrobić
1. Odpal Claude Code w tym folderze.
2. Napisz: ustaw mi globalnie hook dźwiękowy, gdy skończysz odpowiadać, i inny, gdy czekasz na moją decyzję.
3. Gdy skończy, przetestuj: zadaj dowolne pytanie i posłuchaj. Potem otwórz inny projekt i sprawdź, że dźwięk dalej działa.

Gdy to przeczytasz, skasuj ten plik, żeby nie mieszał Claude'owi w kontekście. Resztą zajmie się Claude, prowadzi go instrukcja w .claude/CLAUDE.md.
