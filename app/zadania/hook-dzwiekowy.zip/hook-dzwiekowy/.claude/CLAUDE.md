# Instrukcja dla Claude: ustaw dźwięk (hook) globalnie

To folder ćwiczeniowy. Użytkownik uczy się ustawiać dźwiękowy hook w Claude Code. Twoje zadanie: pomóż mu ustawić to GLOBALNIE i przetestować. Zrób całą konfigurację, ale tłumacz krótko, co robisz.

## Co ustawić
- Dwa różne dźwięki, żeby dało się je rozróżnić:
  - event Stop = sygnał, że skończyłeś odpowiadać (zrobione),
  - event Notification = sygnał, że czekasz na decyzję użytkownika (Twoja kolej).
- Zapisz to GLOBALNIE w ~/.claude/settings.json, w bloku hooks. Nie w tym folderze, bo ma działać w każdym projekcie.

## Jak to zrobić dobrze
- Zanim wpiszesz konfigurację, potwierdź aktualną strukturę hooków w oficjalnej dokumentacji (code.claude.com/docs/en/hooks). Nie zgaduj kształtu pliku.
- Wykryj system użytkownika i dobierz polecenie odtwarzające dźwięk:
  - macOS: afplay /System/Library/Sounds/Glass.aiff (Stop) oraz afplay /System/Library/Sounds/Submarine.aiff (Notification).
  - Windows (PowerShell): odtwórz dwa różne wbudowane dźwięki .wav z C:\Windows\Media (np. chimes.wav i notify.wav) przez powershell -c (New-Object Media.SoundPlayer '<plik>').PlaySync().
- Po zapisaniu poproś użytkownika, żeby przetestował. Zmiany w settings.json łapią się bez restartu.
- Gdy użytkownik pyta, jakie hooki są dostępne, podaj aktualną, pełną listę na podstawie dokumentacji, nie z pamięci.

## Bonus (jeśli użytkownik chce)
- Zbuduj prostą stronę HTML z listą wszystkich wbudowanych dźwięków systemowych i przyciskiem odsłuchania każdego, żeby użytkownik wybrał ulubiony uchem, a potem ustawił go jako dźwięk Stop.
