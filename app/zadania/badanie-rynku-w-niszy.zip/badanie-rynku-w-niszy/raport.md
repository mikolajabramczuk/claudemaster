# Raport z badania rynku

Na razie pusto. Ten plik wypełni składacz, kiedy badacze skończą zbierać notatki.

Po odpaleniu researchu znajdziesz tu: streszczenie rynku, sekcje gracze, ceny, opinie, luki, trendy oraz rekomendację na końcu.
