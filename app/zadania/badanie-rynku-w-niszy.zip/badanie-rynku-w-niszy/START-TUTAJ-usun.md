# Start tutaj (przeczytaj i usuń ten plik)

W tym zadaniu research rynku robi za Ciebie kilku tanich agentów naraz, a jeden mocniejszy skleja z tego raport. Pełny opis i podpowiedzi masz w aplikacji, tu jest tylko szybki start.

Gdy przeczytasz te trzy kroki, skasuj ten plik. Dzięki temu nie będzie się mieszał Claude'owi, kiedy zacznie pracować.

## 3 kroki

1. Otwórz ten folder w Claude Code (odpal Claude w tym folderze).
2. Wpisz Claude polecenie w stylu:
   „Zrób research rynku z brief.md. Odpal pięciu badaczy naraz, każdy bierze jeden wycinek, notatki zapisz w notatki/. Potem składaczem złóż wszystko w raport.md."
3. Patrz, jak pięciu badaczy pracuje w tym samym czasie. Gdy skończą, otwórz raport.md.

Nisza jest już wpisana w brief.md (CRM dla freelancerów). Chcesz swoją? Podmień ją w brief.md i odpal jeszcze raz.
