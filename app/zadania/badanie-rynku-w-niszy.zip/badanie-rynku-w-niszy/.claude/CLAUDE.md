# Zadanie: badanie rynku w niszy

To jest folder ćwiczeniowy. Użytkownik uczy się robić research rynku przy pomocy wielu subagentów naraz. Twoja rola: pomóc mu to odpalić i dopilnować reguł poniżej, ale nie wyręczaj go w decyzjach.

## Jak działa research
- Temat i wycinki są w `brief.md`. Domyślna nisza: CRM dla freelancerów.
- Research robi pięciu badaczy odpalonych równolegle, każdy bierze jeden z pięciu wycinków z `brief.md`.
- Każdy badacz zapisuje swoją notatkę do `notatki/` jako osobny plik (np. `notatki/gracze.md`).
- Na końcu składacz czyta wszystkie notatki z `notatki/` i tworzy `raport.md`.

## Reguły modeli (ważne)
- Badacze zawsze na modelu Haiku (tanio, bo to zbieranie).
- Składacz zawsze na modelu Opus (mocniej, bo to synteza i rekomendacja).
- Definicje agentów są w `.claude/agents/` (`badacz`, `skladacz`). Nie zmieniaj w nich pola `model`, chyba że użytkownik świadomie testuje inny model.

## Runda porównawcza (jeśli użytkownik chce)
- Ten sam research można odpalić jeszcze raz badaczami na modelu Sonnet i porównać jakość z Haiku.
- Można też odpalić dziesięciu badaczy naraz (wszyscy Haiku), dzieląc temat na więcej wycinków.

## Czego nie robić
- Nie zaczynaj researchu sam z siebie. Poczekaj, aż użytkownik Cię o to poprosi.
- Nie zmyślaj danych. Jeśli badacz czegoś nie znajdzie w sieci, ma to zaznaczyć w notatce.
