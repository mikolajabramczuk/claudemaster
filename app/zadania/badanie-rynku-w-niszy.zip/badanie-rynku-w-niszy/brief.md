# Brief researchu

## Nisza
CRM dla freelancerów.

(Narzędzia do zarządzania kontaktami, klientami i sprzedażą, skrojone pod jednoosobowy biznes, nie pod duże firmy.)

## Pięć wycinków (po jednym na badacza)
1. Gracze i konkurenci: kto jest na rynku, najwięksi i ciekawi mniejsi gracze, czym się różnią.
2. Ceny i pakiety: ile to kosztuje, modele cenowe, co jest w darmowym planie, a co płatne.
3. Opinie i narzekania klientów: co ludzie chwalą, na co narzekają, czego im brakuje (recenzje, fora, social media).
4. Luki i nisze: czego na rynku nie ma, gdzie jest miejsce dla nowego gracza, jakie potrzeby są nieobsłużone.
5. Trendy i kierunek: dokąd zmierza rynek, co wchodzi (np. AI), czego będzie więcej.

## Format notatki badacza
Każdy badacz zapisuje krótką notatkę do `notatki/` (osobny plik na wycinek). W notatce: najważniejsze ustalenia w punktach + linki do źródeł. Bez lania wody.

## Dostosuj pod własną niszę
Chcesz badać swój rynek? Podmień niszę wyżej na własną (np. „narzędzia do fakturowania dla fotografów") i, jeśli trzeba, dopisz albo zmień wycinki. Potem odpal research jeszcze raz.
