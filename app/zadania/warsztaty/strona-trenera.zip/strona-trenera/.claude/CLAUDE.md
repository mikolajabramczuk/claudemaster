# TomFit, strona trenera personalnego Tomasza Nowaka

Strona-wizytówka trenera personalnego z Warszawy. Jeden cel biznesowy: zapisy na darmowy trening próbny przez formularz kontaktowy.

## Zasady projektu

- Cała strona to JEDEN plik `index.html`: style w `<style>`, skrypty w `<script>`. Bez frameworków, bibliotek i zewnętrznych zależności.
- Strona musi działać po otwarciu pliku bezpośrednio w przeglądarce, bez serwera i bez internetu.
- Treść po polsku.
- Sekcje strony: hero, o mnie, pakiety z cennikiem, opinie podopiecznych, formularz zapisu na trening próbny, stopka.
- Grupa docelowa: zabiegani ludzie 30+, którzy chcą w końcu zadbać o formę. Ton: konkretny, motywujący, bez żargonu siłownianego.
